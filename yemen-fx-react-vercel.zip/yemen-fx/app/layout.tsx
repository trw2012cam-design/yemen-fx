import "./globals.css";

export const metadata = {
  title: "Yemen FX — Sana'a & Aden",
  description: "USD/SAR to YER, with Sana'a (old notes) and Aden (new notes) — auto-refresh and converter",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
