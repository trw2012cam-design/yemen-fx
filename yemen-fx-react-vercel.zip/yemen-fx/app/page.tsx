'use client'

import React, { useEffect, useMemo, useState } from 'react'

const YETI_URL =
  'https://yemen.yeti.acaps.org/api/telegram_exchange_rates/?format=json'
const FX_URL = 'https://api.exchangerate.host/latest?base=USD&symbols=SAR'

const useProxy =
  typeof window !== 'undefined' && process.env.NEXT_PUBLIC_PROXY === '1'
const proxify = (url: string) => (useProxy ? `/api/proxy?url=${encodeURIComponent(url)}` : url)

interface YetiRow {
  date: string
  pair: string
  value: number
  location_label: string
}

export default function Page() {
  const [sanaaUSD, setSanaaUSD] = useState<number | null>(null)
  const [adenUSD, setAdenUSD] = useState<number | null>(null)
  const [usdToSAR, setUsdToSAR] = useState<number | null>(null)
  const [lastDate, setLastDate] = useState<Date | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [amount, setAmount] = useState<number>(1000)
  const [from, setFrom] = useState<'sanaa' | 'aden'>('sanaa')
  const [to, setTo] = useState<'sanaa' | 'aden'>('aden')

  const fetchOnce = async () => {
    try {
      setError(null)
      setLoading(true)

      const [yemenRes, fxRes] = await Promise.all([
        fetch(proxify(YETI_URL), { cache: 'no-store' }),
        fetch(proxify(FX_URL), { cache: 'no-store' }),
      ])

      if (!yemenRes.ok) throw new Error(`YETI HTTP ${yemenRes.status}`)
      if (!fxRes.ok) throw new Error(`FX HTTP ${fxRes.status}`)

      const yemenJson = await yemenRes.json()
      const fxJson = await fxRes.json()

      const rows: YetiRow[] = Array.isArray(yemenJson) ? yemenJson : (yemenJson.results || yemenJson)

      const latestDate = rows
        .filter((r) => r.pair === 'USD/YER')
        .map((r) => new Date(r.date))
        .sort((a, b) => b.getTime() - a.getTime())[0]

      if (!latestDate) throw new Error('No USD/YER rows found')

      const sameDay = rows.filter(
        (r) => r.pair === 'USD/YER' && new Date(r.date).toDateString() === latestDate.toDateString()
      )

      const sanaaRow = sameDay.find(
        (r) => /Old Notes.*Sana/i.test(r.location_label) || /Sana'a/i.test(r.location_label)
      )
      const adenRow = sameDay.find((r) => /New Notes.*Aden/i.test(r.location_label) || /Aden/i.test(r.location_label))

      const usdSar = fxJson?.rates?.SAR as number | undefined
      if (!usdSar) throw new Error('No SAR rate in FX response')

      setSanaaUSD(sanaaRow?.value ?? null)
      setAdenUSD(adenRow?.value ?? null)
      setUsdToSAR(usdSar)
      setLastDate(latestDate)
    } catch (e: any) {
      console.error(e)
      setError(e?.message || 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchOnce()
    const id = setInterval(fetchOnce, 5 * 60 * 1000)
    return () => clearInterval(id)
  }, [])

  const sanaaSAR = useMemo(() => {
    if (sanaaUSD && usdToSAR) return sanaaUSD / usdToSAR
    return null
  }, [sanaaUSD, usdToSAR])

  const adenSAR = useMemo(() => {
    if (adenUSD && usdToSAR) return adenUSD / usdToSAR
    return null
  }, [adenUSD, usdToSAR])

  const converted = useMemo(() => {
    if (!sanaaUSD || !adenUSD) return null
    const amt = Number.isFinite(amount) ? amount : 0
    const toUSD = from === 'sanaa' ? amt / sanaaUSD : amt / adenUSD
    const result = to === 'sanaa' ? toUSD * sanaaUSD : toUSD * adenUSD
    return new Intl.NumberFormat('ar-YE').format(Math.round(result))
  }, [amount, from, to, sanaaUSD, adenUSD])

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-6">
      <div className="max-w-5xl mx-auto space-y-4">
        <header>
          <h1 className="text-2xl font-bold">💱 أسعار الصرف اليمني — صنعاء (نقد قديم) & عدن (نقد جديد)</h1>
          <p className="text-slate-400 text-sm mt-1">
            المصدر: ACAPS YETI (USD/YER) + exchangerate.host (USD→SAR). يتم التحديث تلقائيًا كل 5 دقائق.
          </p>
        </header>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 text-red-200">
            حدث خطأ أثناء جلب البيانات: {error}
          </div>
        )}

        <section className="grid gap-4 md:grid-cols-2">
          <Card title="صنعاء — نقد قديم" usd={sanaaUSD} sar={sanaaSAR} lastDate={lastDate} loading={loading} />
          <Card title="عدن — نقد جديد" usd={adenUSD} sar={adenSAR} lastDate={lastDate} loading={loading} />
        </section>

        <section className="bg-slate-800/60 rounded-2xl p-4 shadow">
          <h2 className="text-lg font-semibold">🔄 تحويل بين الريال اليمني (صنعاء ⇄ عدن)</h2>
          <div className="grid gap-3 md:grid-cols-4 mt-3 items-end">
            <div>
              <label className="block text-sm text-slate-300 mb-1">المبلغ</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(parseFloat(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm text-slate-300 mb-1">من</label>
              <select
                value={from}
                onChange={(e) => setFrom(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="sanaa">صنعاء (قديمة)</option>
                <option value="aden">عدن (جديدة)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-slate-300 mb-1">إلى</label>
              <select
                value={to}
                onChange={(e) => setTo(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="aden">عدن (جديدة)</option>
                <option value="sanaa">صنعاء (قديمة)</option>
              </select>
            </div>
            <div>
              <button className="w-full px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 transition font-semibold">
                حوِّل
              </button>
              <div className="mt-2 text-xl font-bold">
                {converted ? <span>≈ {converted} ريال {to === 'sanaa' ? 'صنعاء' : 'عدن'}</span> : <span className="text-slate-400">—</span>}
              </div>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-2">
            طريقة الحساب: التحويل عبر الدولار كنقطة محورية (Pivot). مثال: من صنعاء → USD → عدن.
          </p>
        </section>

        <section className="text-slate-400 text-xs">
          <p>
            ملاحظة: قد تمنع بعض الواجهات الطلبات المباشرة من المتصفح (CORS). على الإنتاج، فعِّل مسار API /api/proxy وأضف
            متغير البيئة NEXT_PUBLIC_PROXY=1 في إعدادات Vercel.
          </p>
        </section>
      </div>
    </div>
  )
}

function Card({
  title,
  usd,
  sar,
  lastDate,
  loading,
}: {
  title: string
  usd: number | null
  sar: number | null
  lastDate: Date | null
  loading: boolean
}) {
  return (
    <div className="bg-slate-800/60 rounded-2xl p-4 shadow border border-slate-700/40">
      <h3 className="text-lg font-semibold">{title}</h3>
      <div className="mt-2 space-y-1">
        <Row label="ير / 1 USD" value={usd} large />
        <Row label="ير / 1 SAR" value={sar} large />
      </div>
      <div className="text-slate-400 text-sm mt-2">
        {loading ? 'جاري التحديث…' : lastDate ? `آخر تحديث: ${lastDate.toLocaleString('ar-YE')}` : '—'}
      </div>
    </div>
  )
}

function Row({ label, value, large }: { label: string; value: number | null; large?: boolean }) {
  return (
    <div className="flex items-baseline gap-2">
      <div className={large ? 'text-2xl font-bold' : 'text-base font-semibold'}>
        {value ? new Intl.NumberFormat('ar-YE').format(Math.round(value)) : '—'}
      </div>
      <div className="text-slate-300">{label}</div>
    </div>
  )
}
